1.	It is the login page. Login with the previously registered account information (valid email and password). If you do not have an existing account, a new account is created using the register. It will ask for name, surname, valid email, birth date, and profile picture. (index.php)
2.	After logging in with account information, the main page is reached. It includes components to search for friends, add friends, create new posts, view notifications, view friends, view the posts we have created and view the posts of friends on the timeline.(timeline.php)
3.	In the user search section, a search is made using the user name or user e-mail address and can be added as a friend in order to send friend requests to the people who appear.
4.	In the notifications section, incoming friendships are listed, accepted or rejected.
5.	Current friends are listed in the friends section. When users delete a friend, a notification is sent to the corresponding friend.
6.	In the my posts section, the posts we created before are listed, any of the posts can be deleted if desired.
7.	In the post creation section, the content of the post is written and if desired, it can be shared by adding an image from the upload section. The friends can make comments on the posts, and may check like or unlike buttons.
8.	The users will see the posts shared by their friends on the timeline. At a time, it shows up to 10 posts, at the end of the posts, a next button retrieve the next 10 posts.
9.	Sign out of account by logout.